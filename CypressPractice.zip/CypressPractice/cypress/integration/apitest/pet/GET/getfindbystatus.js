/// <reference types="Cypress" />

describe('get api pet find by status test', () => {
    it('get pet find by status', () => {
        cy.request({
            method: 'GET',
            url: 'https://petstore.swagger.io/v2/pet/findByStatus?status=available'
        }).then((res) => {
            expect(res.status).to.eq(200)

        })
    })
})