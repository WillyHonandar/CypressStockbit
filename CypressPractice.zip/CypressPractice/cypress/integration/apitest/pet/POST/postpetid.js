/// <reference types="Cypress" />

describe('post api pet by id', () => {
    it('post pet by id', () => {
        cy.request({
            method: 'POST',
            url: 'https://petstore.swagger.io/v2/pet/123'
        }).then((res) => {
            expect(res.status).to.eq(200)

        })
    })
})