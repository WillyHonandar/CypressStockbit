/// <reference types="Cypress" />

describe('put api pet test', () => {
    let randomText = ""
    let testEmail = ""
    let testName = ""

    it('put pet', () => {
        var pattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        for (var i = 0; i < 10; i++)
            randomText += pattern.charAt(Math.floor(Math.random() * pattern.length));
        testEmail = randomText + '@gmail.com'
        testName = randomText + ' username'

        cy.request({
            method: 'POST',
            url: 'https://petstore.swagger.io/v2/pet',
            body: {
                "id": 123,
                "category": {
                    "id": 0,
                    "name": testName + 'Update'
                },
                "name": testName + 'Update',
                "photoUrls": [
                    testName + 'Update'
                ],
                "tags": [
                    {
                        "id": 0,
                        "name": testName + 'Update'
                    }
                ],
                "status": "available"
            },
            failOnStatusCode: false
        }).then((res) => {
            cy.log(JSON.stringify(res))
            // expect(res.status).to.be.gt(299)
            expect(res.status).to.eq(200)


        })
    })
})