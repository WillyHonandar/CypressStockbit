/// <reference types="Cypress" />

describe('post api pet test', () => {
    let randomText = ""
    let testEmail = ""
    let testName = ""

    it('post pet', () => {
        var pattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        for (var i = 0; i < 10; i++)
            randomText += pattern.charAt(Math.floor(Math.random() * pattern.length));
        testEmail = randomText + '@gmail.com'
        testName = randomText + ' username'

        cy.request({
            method: 'POST',
            url: 'https://petstore.swagger.io/v2/pet',
            body: {
                "id": 123,
                "category": {
                    "id": 0,
                    "name": testName
                },
                "name": testName,
                "photoUrls": [
                    testName
                ],
                "tags": [
                    {
                        "id": 0,
                        "name": testName
                    }
                ],
                "status": "available"
            },
            failOnStatusCode: false
        }).then((res) => {
            cy.log(JSON.stringify(res))
            // expect(res.status).to.be.gt(299)
            expect(res.status).to.eq(200)
            expect(res.body).has.property('id', 123)
            expect(res.body.category).has.property('id', 0)
            expect(res.body.category).has.property('name', testName)
            expect(res.body).has.property('name', testName)
            // expect(res.body).has.property('photoUrls', testName)
            // expect(res.body.tags).has.property('id', 0)
            // expect(res.body.tags).has.property('name', testName)
            expect(res.body).has.property('status', 'available')

        }).then((res) => {
            const petId = res.body.id
            cy.log("store id is: " + petId)

            cy.request({
                method: 'GET',
                url: 'https://petstore.swagger.io/v2/pet/' + petId,
            }).then((res) => {
                expect(res.status).to.eq(200)
                expect(res.body).has.property('id', petId)
                expect(res.body.category).has.property('id', 0)
                expect(res.body.category).has.property('name', testName)
                expect(res.body).has.property('name', testName)
                // expect(res.body).has.property('photoUrls', testName)
                // expect(res.body.tags).has.property('id', 0)
                // expect(res.body.tags).has.property('name', testName)
                expect(res.body).has.property('status', 'available')
            })
        })
    })
})