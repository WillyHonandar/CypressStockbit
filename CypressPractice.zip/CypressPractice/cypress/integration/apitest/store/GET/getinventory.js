/// <reference types="Cypress" />

describe('get api store inventory test', () => {
    it('get store inventory', () => {
        cy.request({
            method: 'GET',
            url: 'https://petstore.swagger.io/v2/store/inventory'
        }).then((res) => {
            expect(res.status).to.eq(200)

        })
    })
})