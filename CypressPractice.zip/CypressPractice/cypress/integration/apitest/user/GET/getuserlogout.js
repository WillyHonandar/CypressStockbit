/// <reference types="Cypress" />

describe('get api user logout test', () => {
    it('get user logout', () => {
        cy.request({
            method: 'GET',
            url: 'https://petstore.swagger.io/v2/user/logout'
        }).then((res) => {
            expect(res.status).to.eq(200)

        })
    })
})