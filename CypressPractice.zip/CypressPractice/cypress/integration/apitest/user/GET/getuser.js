/// <reference types="Cypress" />

describe('get api user test', () => {
    it('get user', () => {
        cy.request({
            method: 'GET',
            url: 'https://petstore.swagger.io/v2/user/string'
        }).then((res) => {
            expect(res.status).to.eq(200)

        })
    })
})