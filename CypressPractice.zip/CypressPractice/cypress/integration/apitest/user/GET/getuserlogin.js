/// <reference types="Cypress" />

describe('get api user login test', () => {
    it('get user login', () => {
        cy.request({
            method: 'GET',
            url: 'https://petstore.swagger.io/v2/user/login?username=string&password=string'
        }).then((res) => {
            expect(res.status).to.eq(200)

        })
    })
})