/// <reference types="Cypress" />


// const dataJSON = require('../../fixtures/createuser')

describe('post api user with list test', () => {
    let randomText = ""
    let testEmail = ""
    let testUsername = ""

    it('post user wwith list', () => {
        var pattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        for (var i = 0; i < 10; i++)
            randomText += pattern.charAt(Math.floor(Math.random() * pattern.length));
        testEmail = randomText + '@gmail.com'
        testUsername = randomText + ' username'

        cy.request({
            method: 'POST',
            url: 'https://petstore.swagger.io/v2/user/createWithList',
            body: [{
                "username": testUsername,
                "firstName": "User",
                "lastName": "Test",
                "email": testEmail,
                "password": "123",
                "phone": "123",
                "userStatus": 0
            }],
            failOnStatusCode: false
        }).then((res) => {
            cy.log(JSON.stringify(res))
            // expect(res.status).to.be.gt(299)
            expect(res.status).to.eq(200)
            expect(res.body).has.property('code', 200)
            expect(res.body).has.property('type', 'unknown')
            expect(res.body).has.property('message', "ok")
            // expect(res.body.data).has.property('firstName', "User")
            // expect(res.body.data).has.property('lastName', "Test")
            // expect(res.body.data).has.property('email', testEmail)
            // expect(res.body.data).has.property('password', "123")
            // expect(res.body.data).has.property('phone', "123")
            // expect(res.body.data).has.property('userStatus', 0)

        }).then((res) => {

        })
    })
})